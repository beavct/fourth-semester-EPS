#include <iostream>
#include "labirinto.hpp"
#include "personagem.hpp"
#include "fantasma.hpp"
#include "partida.hpp"
#define MAX 256

using namespace std;

int main(){
    Partida partidaTeste;

    partidaTeste.iniPartidaLocal();

    return 0;
}

